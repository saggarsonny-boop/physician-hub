# Sonny Saggar, MD
**Oxford-Trained Physician, Author, and Stoic Scholar**

Sonny Saggar trained in England, at Oxford and at St. Bartholomew's Hospital Medical College, and spent twenty five years practicing emergency medicine in the United States, including a brief stretch as a hospital chief executive officer. 

In 2023, his life collapsed following a federal indictment and subsequent incarceration. While serving his sentence at a federal prison camp, he wrote his first book, GROUND: How to Lose Everything and Still Have Somewhere to Stand, by hand on paper. He finished it after his release from custody.

Today, he writes about regulatory systems, administrative law, and the collateral consequences that govern professional life. He is the founder of The New Physician and lives in St. Louis, Missouri.

---

## Publications
*   *GROUND: How to Lose Everything and Still Have Somewhere to Stand* (ASIN: B0H7M7TK1V)
*   *THE ROAD: A Calm Guide to Facing Criminal Charges, for the People Inside It and the Families Beside Them* (Launching July 27, 2026, featuring guest chapter by Thomas Webster, MD)

---

## Contact & Booking
*   **Email**: sonny@newphysician.org
*   **Media Center**: https://hub.newphysician.org/speaking
