# Sample Interview Questions: Sonny Saggar, MD

Suggested prompts for podcast hosts and media interviewers.

---

## Stoicism & Internal Footing
1.  What is the difference between losing external assets and being internally lost?
2.  How did you apply Stoic philosophy during your first week at the federal prison camp?
3.  Why do you write that "bouncing back" is a fallacy after severe collapse?
4.  Why do you refuse to say that "everything happens for a reason"?

---

## Legal Processes & The Family Unit
5.  Why is the Presentence Investigation Report (PSR) the most critical document in a case?
6.  How can families construct stress boundaries when a parent faces federal charges?
7.  What does a defense lawyer handle, and what must the defendant manage themselves?

---

## Systems & Regulation
8.  How do administrative coding audits sometimes lead to criminal fraud charges?
9.  Why did you choose to write GROUND entirely by hand on paper?
10. What did your emergency medicine training teach you about analyzing systemic failure?
